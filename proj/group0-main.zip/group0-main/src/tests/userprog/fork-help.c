#include <stdlib.h>
#include <syscall.h>
#include "tests/lib.h"

int main(int argc, char* argv[]) { return 161; }